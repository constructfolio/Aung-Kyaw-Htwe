# Aung Kyaw Htwe — Portfolio Website

Personal portfolio for **Aung Kyaw Htwe**, Senior Interior Designer & Remote Design Lead.

Live site: `https://<your-username>.github.io/akh-portfolio`

---

## Stack

- Pure HTML5 + CSS3 + Vanilla JS
- No frameworks, no build step
- Fonts: [Cormorant Garamond + DM Sans](https://fonts.google.com/) via Google Fonts
- Images: [Unsplash](https://unsplash.com/) (replace with your own)

## File Structure

```
akh-portfolio/
├── index.html        ← entire site (single file)
└── README.md
```

## Deploy to GitHub Pages

1. Push this repo to GitHub
2. Go to **Settings → Pages**
3. Source: `Deploy from a branch`
4. Branch: `main` / `(root)`
5. Save — live in ~60 seconds at `https://<username>.github.io/<repo-name>`

## Customise

| What | Where in `index.html` |
|---|---|
| Project images | `<img src="https://images.unsplash.com/...">` — swap URLs |
| Contact details | Footer `#contact` section |
| Skills / pills | `#skills` section |
| Timeline entries | `#experience` section |
| Colour palette | `:root` CSS variables at top of `<style>` |

## License

All rights reserved © 2025 Aung Kyaw Htwe.
